#author: Maxwell Woehrmann
#date: November 1, 2018
#needed libraries: python-twitch-client, matplotlib, NumPy, SciPy


#This program prompts the user for a game and then creates an array containing every streamers
#view count for the given video game. Next, the cumulative view proportion vs cumulative population proportion
#is graphed and the Gini Coefficient is calculated. A score is presented (the reciprocal of the Gini coefficient)
#to the user, exhibiting how close the game is to being a perfectly equal streaming environment

#eventually, i hope to have data on which hour is best to stream for a given game
#I will collect the score value once every half hour for the top 100 games and store the values in
#a JSON file as arrays. eventually I will be able to tell the user exactly which day and specific
#time for a given game is the best to stream based on viewership equality among channels

from twitch import TwitchClient
from matplotlib import pyplot as plt
import numpy as np
from scipy import stats
from scipy.integrate import simps

#a unique client id must be provided for the API to be accessible
#go to: https://dev.twitch.tv/
#and create an account then create an app, you will be provided with a unique client_id
client = TwitchClient(client_id='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')


#This creates an array with an entry for each channel streaming the given game that contains
#thats stream's view count
#the API only offers streams in batches of 100 so when there are more than 100 channels
#active, they must be divided into consumable pieces.
def gatherViewership():
    
    #pagination amount tells the API how many streams to skip before beginning collection
    pagAmount = 0
    catSize = totChannels
    remainder = catSize%100
    runs = int(catSize/100)
    pos = 0

    #collects as many 100-stream sized groupings as possible
    while(runs>0):
        catStreams = client.streams.get_live_streams(None,gameName,None,"live",100,pagAmount)
        for stream in catStreams:
            views[pos] = (100*stream['viewers'])/totViewers
            pos = pos + 1
        pagAmount = pagAmount + 100
        runs = runs - 1

    #collects the remaining number of streams (some value <100)
    catStreams = client.streams.get_live_streams(None,gameName,None,"live",remainder,pagAmount)
    for stream in catStreams:
        views[pos] = (100*stream['viewers'])/totViewers
        pos = pos + 1

#Graphs and labels both the axis and the plotted lines
def graphData():
    plt.plot(c,d, "--", label="perfect equality")
    plt.plot(a,b, label="observed")
    plt.xlabel("Cumulative Percentage of Population")
    plt.ylabel("Cumulative Percentage of Viewers")

    plt.text(-2,82, ("Score = " + str(score)), fontsize = 14)
    plt.text(34,97, ("Total Channels = " + str(totChannels)), fontsize = 10)
    plt.text(34,92, ("Total Viewers = " + str(totViewers)), fontsize = 10)
    plt.title(gameName.upper())
    plt.legend()
    plt.show()


#this generates a score for the game by finding the Gini coefficient
#this is done by dividing the area between the perfect equality and the
#observed equality line by that value plus the area below the observed
#value line. Next, it returns the reciprocal of this value, because
#it is more intuitive to the user if a higher "score" means greater equality
def generateScore():
    belowPerfect = simps(c, d)
    belowObserved = simps(b, a)
    A = belowPerfect - belowObserved
    score = A/(A+belowObserved)
    return round(1/score,3)
    #once i start collecting data from multiple games, i will be able to create
    #a comparative grading system. that way, the score can be interpreted as
    #an A, B, C, D, or F, based off how a given game scores relative to the other games


if __name__ == '__main__':
    response = "yes"
    #these data sets will be used to graph the perfect equality line
    c = [0, 100]
    d = [0, 100]
    while(response == "yes"):
        gameName = input("What game would you like to analyse? ")
        gameSummary = client.streams.get_summary(gameName)
        totChannels = gameSummary['channels']
        totViewers = gameSummary['viewers']
        print("There are currently " + str(totChannels) + " channels streaming " + gameName + " for a total of " + str(totViewers) + " viewers.")

        a = [0]*totChannels
        b = [0]*totChannels
        views = [0]*totChannels
        gatherViewership()
        #constructs the data sets of cumulative proportion for population amount and viewer amount
        for x in range(len(views)):
            if(x == 0):
                a[x] = 100/totChannels
                b[x] = views[totChannels-1]
            else:
                a[x] = a[x-1] + 100/totChannels
                b[x] = b[x-1] + views[totChannels-x-1]

        score = generateScore()
        graphData()
        print("This game gets a score of " + str(score) + ".")
        print("The higher the score, the greater the equality of viewer distribution. 1 is worst possible score.")
        response = input("\nAre there more games you want to analyse? (Respond 'yes' or 'no'): ")
